# Multi Brute Force

cookies method with python2 version
![MBF]

## Installation
```
pkg install python2
pip2 install requests bs4
```

## Run script
```
cd mbf
python2 bismillah.py
```

## Contact
[Facebook](https://www.facebook.com/profile.php?id=100030230222230)
[Whatsapp: 6285641596738)
